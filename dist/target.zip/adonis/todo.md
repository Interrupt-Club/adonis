// 1. Gatsby HEAD -> https://www.gatsbyjs.com/docs/reference/built-in-components/gatsby-head/
// 2. SEO on each page